package com.example.project4task2;
/**
 * CatPicture Activity: Allows the user to search for cat breed information
 * by entering the breed name. It fetches data from a server, displays the
 * breed information and image.
 *
 * @author Yunqing Xiao
 * @andrewId yunqingx
 * @date 11/19/2024
 */
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.picasso.Picasso;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class CatPicture extends AppCompatActivity {
    private EditText etBreedName;  // Input field for breed name
    private Button btnSearch;     // Button to trigger search
    private TextView tvBreedInfo; // TextView to display breed information
    private ImageView ivCatImage; // ImageView to display cat image

    /**
     * Initializes the activity and sets up the UI components.
     *
     * @param savedInstanceState the saved state of the activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cat_picture);

        // Initialize Views
        etBreedName = findViewById(R.id.etBreedName);
        btnSearch = findViewById(R.id.btnSearch);
        tvBreedInfo = findViewById(R.id.tvBreedInfo);
        ivCatImage = findViewById(R.id.ivCatImage);

        // Set Button Click Listener
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String breedName = etBreedName.getText().toString().trim();
                // Validate input
                if (!breedName.isEmpty()) {
                    fetchCatInfo(breedName);
                } else {
                    Toast.makeText(CatPicture.this, "Please enter a breed name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Fetches cat breed information from the server based on the provided breed name.
     *
     * @param breedName the name of the breed to search
     */
    private void fetchCatInfo(String breedName) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                // Build the URL for the server request
                String urlString = "https://miniature-doodle-rrqpg676pjqcjvj-8080.app.github.dev/"
                        + "catsearch?query=" + breedName;
                System.out.println("Request URL: " + urlString);

                // Establish connection
                URL url = new URL(urlString);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Accept", "application/json");
                connection.setConnectTimeout(60000);
                connection.setReadTimeout(60000);

                // Get response code
                int responseCode = connection.getResponseCode();
                System.out.println("Response Code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Read server response
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    // Debug log
                    System.out.println("Response: " + response.toString());

                    // Parse JSON response
                    parseCatInfo(response.toString());
                } else {
                    // Handle non-OK response codes
                    System.out.println("Error: HTTP response code " + responseCode);
                    runOnUiThread(() -> Toast.makeText(CatPicture.this, "Error: " + responseCode, Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(CatPicture.this, "Failed to fetch data", Toast.LENGTH_SHORT).show());
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    /**
     * Parses the JSON response from the server and updates the UI with cat breed information.
     *
     * @param jsonResponse the JSON response as a string
     */
    private void parseCatInfo(String jsonResponse) {
        try {
            // Parse JSON using Gson
            JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();
            JsonObject breedInfo = jsonObject.getAsJsonObject("breedInfo");
            String name = breedInfo.get("name").getAsString();
            String description = breedInfo.get("description").getAsString();
            String imageUrl = jsonObject.get("catImage").getAsString();

            // Update UI with the parsed data
            runOnUiThread(() -> {
                tvBreedInfo.setText(name + "\n" + description);
                Picasso.get().load(imageUrl).into(ivCatImage);
            });
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() -> Toast.makeText(CatPicture.this, "Failed to parse data", Toast.LENGTH_SHORT).show());
        }
    }
}